<?php
require_once('include/cDB.php');
require_once('include/CestaCompra.php');

// Recuperamos la información de la sesión
session_start();

// Y comprobamos que el usuario se haya autentificado
if (!isset($_SESSION['usuario'])) 
    die("Error - debe <a href='login.php'>identificarse</a>.<br />");

// Recuperamos la cesta de la compra
$cesta = CestaCompra::carga_cesta();

// Comprobamos si se ha enviado el formulario de vaciar la cesta
if (isset($_POST['vaciar'])) {
    unset($_SESSION['cesta']);
    $cesta = new CestaCompra();
}

// Comprobamos si se quiere añadir un producto a la cesta
if (isset($_POST['enviar'])) {
    $cesta->nuevo_articulo($_POST['cod']);
    $cesta->guarda_cesta();
}

// Creamos una función para mostrar el listado de todos los productos 
function creaFormularioProductos() {
	$productos = DB::obtieneProductos();
	foreach ($productos as $p) {
		$c= $p->getcodigo();
		$nc= $p->getnombrecorto();
		$PVP= $p->getPVP();
		// Creamos el formulario en HTML para cada producto
		echo "<p><form id='$c' action='productos.php' method='post'>";
        // Metemos ocultos los datos de los productos
        echo "<input type='hidden' name='cod' value='".$c."'/>";
        echo "<input type='hidden' name='nombre' value='".$nc."'/>";
        echo "<input type='hidden' name='precio' value='".$PVP."'/>";
        echo "<input type='submit' name='enviar' value='Añadir'/>";
        echo " $nc: ";
        echo $PVP." euros.";
        echo "</form>"; 
        echo "</p>";
	}        
}


 
?>

<!DOCTYPE html>
<!-- Desarrollo Web en Entorno Servidor -->
<!-- Tema 5 : Programación orientada a objetos en PHP -->
<!-- Ejemplo Tienda Web: productos.php -->
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <title>Ejemplo Tema 5: Listado de Productos</title>
  <link href="tienda.css" rel="stylesheet" type="text/css">
</head>

<body class="pagproductos">

<div id="contenedor">
  <div id="encabezado">
    <h1>Listado de productos</h1>
  </div>
  <div id="cesta">
    <h3><img src="cesta.png" alt="Cesta" width="24" height="21"> Cesta</h3>
    <hr />
<?php	
	$productos= $cesta->get_productos();
	foreach($productos as $p => $producto) {
		$c= $producto->getcodigo();
		echo "<span class='nombre'>$c </br> </span>";  
    } 
?>
    <form id='vaciar' action='productos.php' method='post'>
        <input type='submit' name='vaciar' value='Vaciar Cesta' 
            <?php if ($cesta->vacia()) print "disabled='true'"; ?>
        />
    </form>
    <form id='comprar' action='cesta.php' method='post'>
        <input type='submit' name='comprar' value='Comprar' 
            <?php if ($cesta->vacia()) print "disabled='true'"; ?>
        />
    </form>
  </div>
  <div id="productos">
<?php		CreaFormularioProductos();  ?>
  </div>
  
  <br class="divisor" />
  <div id="pie">
    <form action='logoff.php' method='post'>
        <input type='submit' name='desconectar' value='Desconectar usuario <?php echo $_SESSION['usuario']; ?>'/>
    </form>        
<?php
    if (isset($error)) {
        print "<p class='error'>Error $error: $mensaje</p>";
    }
?>
  </div>
</div>
</body>
</html>
