<?php
require_once('include/CestaCompra.php');

// Recuperamos la información de la sesión
session_start();

// Y comprobamos que el usuario se haya autentificado
if (!isset($_SESSION['usuario'])) 
    die("Error - debe <a href='login.php'>identificarse</a>.<br />");

// Recuperamos la cesta de la compra
$cesta = CestaCompra::carga_cesta();

?>
<!DOCTYPE html>
<!-- Desarrollo Web en Entorno Servidor -->
<!-- Tema 5 : Programación orientada a objetos en PHP -->
<!-- Ejemplo Tienda Web: cesta.php -->
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <title>Ejemplo Tema 5: Cesta de la Compra</title>
  <link href="tienda.css" rel="stylesheet" type="text/css">
</head>

<body class="pagcesta">

<div id="contenedor">
  <div id="encabezado">
    <h1>Cesta de la compra</h1>
  </div>
  <div id="productos">
<?php
	$productos= $cesta->get_productos();
    foreach($productos as $p => $producto) { 
        $c= $producto->getcodigo();
		$nc= $producto->getnombrecorto();
		$pvp= $producto->getPVP();
		echo "<p><span class='codigo'>$c</span>";
        echo "<span class='nombre'>$nc</span>";
        echo "<span class='precio'>$pvp</span></p>"; 
       
    }
?>
      <hr />
      <p><span class='pagar'>Precio total: <?php print $cesta->get_coste(); ?> €</span></p>
      <form action='pagar.php' method='post'>
          <p>
              <span class='pagar'>
                    <input type='submit' name='pagar' value='Pagar'/>
              </span>
          </p>
      </form>                  
  </div>
  <br class="divisor" />
  <div id="pie">
    <form action='logoff.php' method='post'>
        <input type='submit' name='desconectar' value='Desconectar usuario <?php echo $_SESSION['usuario']; ?>'/>
    </form>        
  </div>
</div>
</body>
</html>
